var express= require("express");
var app=express();


var bodyParser = require('body-parser');

// support parsing of application/json type post data
app.use(bodyParser.json());

//support parsing of application/x-www-form-urlencoded post data
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine","ejs");

 var campgrounds=[
        {name:"riya",image:"https://images.unsplash.com/photo-1476610182048-b716b8518aae?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1127&q=80"},
        {name:"hiana",image:"https://cdn.pixabay.com/photo/2015/06/18/12/26/lake-813655_1280.jpg"},
        {name:"moni",image:"https://images.unsplash.com/photo-1526427158867-98ee4ba58d5a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80"},
        {name:"tapasi",image: "https://images.unsplash.com/photo-1529528070131-eda9f3e90919?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80"},
        {name:"riya",image:"https://images.unsplash.com/photo-1476610182048-b716b8518aae?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1127&q=80"},
        {name:"hiana",image:"https://cdn.pixabay.com/photo/2015/06/18/12/26/lake-813655_1280.jpg"},
        {name:"moni",image:"https://images.unsplash.com/photo-1526427158867-98ee4ba58d5a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80"},
        {name:"tapasi",image: "https://images.unsplash.com/photo-1529528070131-eda9f3e90919?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80"}
        ];


app.get("/",function(req,res){
    res.render("landing");
});
app.get("/campground",function(req,res){
    res.render("campground",{campgrounds:campgrounds});
       
});
 
app.post("/campground",function(req,res){
   
     
     // to get f=data from the form and al it to the campgrounds array
     
     var name= req.body.name;
     var image= req.body.image;
     
     var newEntry={name:name, image:image};
      campgrounds.push(newEntry);
      
     //redirect to campground page
     res.redirect("/campground");
    
});


app.get("/campground/new",function(req,res){
    res.render("new.ejs");

});






app.listen(process.env.PORT,process.env.IP,function(){
    console.log("server started");
   
});
